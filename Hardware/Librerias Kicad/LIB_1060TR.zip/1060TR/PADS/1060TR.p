*PADS-LIBRARY-PART-TYPES-V9*

1060TR 1060TR I ANA 7 1 0 0 0
TIMESTAMP 2026.03.28.19.09.05
"Mouser Part Number" 534-1060TR
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Keystone-Electronics/1060TR?qs=ygfPscbNso3AlRe4cBnpxg%3D%3D
"Manufacturer_Name" Keystone Electronics
"Manufacturer_Part_Number" 1060TR
"Description" Coin Cell Battery Holders 20MM SMT CELL HOLDER
"Datasheet Link" https://componentsearchengine.com/Datasheets/1/1060TR.pdf
"Geometry.Height" 5.51mm
GATE 1 3 0
1060TR
1 0 U +
2 0 U -
3 0 U EP

*END*
*REMARK* SamacSys ECAD Model
702108/502518/2.50/3/4/Undefined or Miscellaneous
