*PADS-LIBRARY-PART-TYPES-V9*

GRM188R61A105KA61D CAPC1608X90N I CAP 7 1 0 0 0
TIMESTAMP 2026.03.29.10.04.05
"Mouser Part Number" 81-GRM39R105K10
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Murata-Electronics/GRM188R61A105KA61D?qs=LlFn95tWfDgsujID1PD8Jw%3D%3D
"Manufacturer_Name" Murata Electronics
"Manufacturer_Part_Number" GRM188R61A105KA61D
"Description" Ceramic  SMT capacitor 1uF 10Vdc Murata 0603 GRM 1uF Ceramic Multilayer Capacitor, 10 V dc, +85C, X5R Dielectric, +/-10%
"Datasheet Link" https://search.murata.co.jp/Ceramy/image/img/A01X/G101/ENG/GRM188R61A105KA61-01A.pdf
"Geometry.Height" 0.9mm
GATE 1 2 0
GRM188R61A105KA61D
1 0 U 1
2 0 U 2

*END*
*REMARK* SamacSys ECAD Model
275196/502518/2.50/2/2/Capacitor
