*PADS-LIBRARY-PART-TYPES-V9*

RC0603FR-07120RL RESC1608X55N I RES 7 1 0 0 0
TIMESTAMP 2026.03.29.10.30.35
"Mouser Part Number" 603-RC0603FR-07120RL
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Yageo/RC0603FR-07120RL?qs=uM1JSSdPjOCKJQFXEGGb5w%3D%3D
"Manufacturer_Name" Yageo Group
"Manufacturer_Part_Number" RC0603FR-07120RL
"Description" YAGEO (PHYCOMP) - RC0603FR-07120RL - RES, THICK FILM, 120R, 1%, 0.1W, 0603
"Datasheet Link" http://www.yageo.com/documents/recent/PYu-RC0603_51_RoHS_L_v5.pdf
"Geometry.Height" 0.55mm
GATE 1 2 0
RC0603FR-07120RL
1 0 U 1
2 0 U 2

*END*
*REMARK* SamacSys ECAD Model
383542/502518/2.50/2/5/Resistor
