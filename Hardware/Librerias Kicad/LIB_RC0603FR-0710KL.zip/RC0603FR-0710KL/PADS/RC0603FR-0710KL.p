*PADS-LIBRARY-PART-TYPES-V9*

RC0603FR-0710KL RESC1608X55N I RES 7 1 0 0 0
TIMESTAMP 2026.03.29.02.31.25
"Mouser Part Number" 603-RC0603FR-0710KL
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/YAGEO/RC0603FR-0710KL?qs=grNVn54RoB%252B3GtjbJj3wJQ%3D%3D
"Manufacturer_Name" Yageo Group
"Manufacturer_Part_Number" RC0603FR-0710KL
"Description" Yageo RC Series Thick Film Surface Mount Resistor 0603 Case 10k
"Datasheet Link" http://www.yageo.com/documents/recent/PYu-RC0603_51_RoHS_L_v5.pdf
"Geometry.Height" 0.55mm
GATE 1 2 0
RC0603FR-0710KL
1 0 U 1
2 0 U 2

*END*
*REMARK* SamacSys ECAD Model
245145/502518/2.50/2/3/Resistor
