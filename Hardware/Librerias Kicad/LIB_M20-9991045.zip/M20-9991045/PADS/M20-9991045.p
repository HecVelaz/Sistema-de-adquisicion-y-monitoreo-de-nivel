*PADS-LIBRARY-PART-TYPES-V9*

M20-9991045 HDRV10W64P0X254_1X10_2540X254X864P I CON 7 1 0 0 0
TIMESTAMP 2026.03.29.12.10.29
"Mouser Part Number" 855-M20-9991045
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Harwin/M20-9991045?qs=%252Bk6%2F5FB6qrlmqe3AuAEP4g%3D%3D
"Manufacturer_Name" Harwin
"Manufacturer_Part_Number" M20-9991045
"Description" M20: 10 Pos Plug SIL Straight 3mm THT Connector 6.1mm pin Gold
"Datasheet Link" https://content.harwin.com/m/0df15f6e0f9f48e2/original/DRG-00479-Technical-Drawing-Datasheet-M20-999-pdf.pdf
"Geometry.Height" 8.64mm
GATE 1 10 0
M20-9991045
1 0 U 1
2 0 U 2
3 0 U 3
4 0 U 4
5 0 U 5
6 0 U 6
7 0 U 7
8 0 U 8
9 0 U 9
10 0 U 10

*END*
*REMARK* SamacSys ECAD Model
233555/2017949/2.50/10/2/Connector
