*PADS-LIBRARY-PART-TYPES-V9*

12063C106KAT2A CAPC3216X229N I CAP 7 1 0 0 0
TIMESTAMP 2026.03.29.10.17.00
"Mouser Part Number" 581-12063C106KAT2A
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/KYOCERA-AVX/12063C106KAT2A?qs=lBCXFVCh2mU%2FEu8zFiPNsQ%3D%3D
"Manufacturer_Name" Kyocera AVX
"Manufacturer_Part_Number" 12063C106KAT2A
"Description" MLCC Capacitor 10uF 1206 X7R 10% 25V AVX 10uF Ceramic Multilayer Capacitor 25 V +/-10% X7R dielectric FlEXITERM SMT max op. temp. +125C
"Datasheet Link" https://spicat.kyocera-avx.com/product/mlcc/chartview/12063C106KAT2A/DataSheet/X7R
"Geometry.Height" 2.29mm
GATE 1 2 0
12063C106KAT2A
1 0 U 1
2 0 U 2

*END*
*REMARK* SamacSys ECAD Model
263982/502518/2.50/2/3/Capacitor
