*PADS-LIBRARY-PART-TYPES-V9*

SS14 DIOM5227X270N I DIO 7 1 0 0 0
TIMESTAMP 2026.03.29.03.28.28
"Mouser Part Number" 512-SS14
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/onsemi-Fairchild/SS14?qs=mVVXn4M53U%252BvrBaFv5vr4w%3D%3D
"Manufacturer_Name" onsemi
"Manufacturer_Part_Number" SS14
"Description" High-Current Capability, Low VF; Glass-Passivated Junctions
"Datasheet Link" https://www.onsemi.com/pub/Collateral/SS19-D.PDF
"Geometry.Height" 2.7mm
GATE 1 2 0
SS14
1 0 U K
2 0 U A

*END*
*REMARK* SamacSys ECAD Model
972457/502518/2.50/2/2/Schottky Diode
