*PADS-LIBRARY-PART-TYPES-V9*

RC0603FR-075K1L RESC1608X55N I RES 7 1 0 0 0
TIMESTAMP 2026.03.29.10.42.41
"Mouser Part Number" 603-RC0603FR-075K1L
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/YAGEO/RC0603FR-075K1L?qs=gt6vzsuosg2jUUwxnI2PJQ%3D%3D
"Manufacturer_Name" Yageo Group
"Manufacturer_Part_Number" RC0603FR-075K1L
"Description" Thick Film Resistors - SMD 5.1K OHM 1%
"Datasheet Link" http://www.yageo.com/documents/recent/PYu-RC0603_51_RoHS_L_v5.pdf
"Geometry.Height" 0.55mm
GATE 1 2 0
RC0603FR-075K1L
1 0 U 1
2 0 U 2

*END*
*REMARK* SamacSys ECAD Model
294005/502518/2.50/2/5/Resistor
