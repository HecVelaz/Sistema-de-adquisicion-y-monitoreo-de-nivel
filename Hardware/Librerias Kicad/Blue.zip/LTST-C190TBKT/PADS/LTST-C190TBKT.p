*PADS-LIBRARY-PART-TYPES-V9*

LTST-C190TBKT LTSTC190TBKT I DIO 7 1 0 0 0
TIMESTAMP 2026.03.29.03.33.58
"Mouser Part Number" 859-LTST-C190TBKT
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Lite-On/LTST-C190TBKT?qs=RX3h6vwoF9jNAGfkgrwfMA%3D%3D
"Manufacturer_Name" Lite-On
"Manufacturer_Part_Number" LTST-C190TBKT
"Description" Standard LEDs - SMD Blue Clear 470nm
"Datasheet Link" http://optoelectronics.liteon.com/upload/download/DS-22-99-0224/LTST-C190TBKT.PDF
"Geometry.Height" 0.9mm
GATE 1 2 0
LTST-C190TBKT
1 0 U K
2 0 U A

*END*
*REMARK* SamacSys ECAD Model
612592/502518/2.50/2/3/LED
