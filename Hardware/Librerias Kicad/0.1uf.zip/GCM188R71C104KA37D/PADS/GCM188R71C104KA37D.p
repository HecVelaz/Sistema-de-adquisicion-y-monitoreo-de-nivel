*PADS-LIBRARY-PART-TYPES-V9*

GCM188R71C104KA37D CAPC1608X90N I CAP 7 1 0 0 0
TIMESTAMP 2026.03.29.09.40.22
"Mouser Part Number" 81-GCM188R71C104KA7D
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Murata-Electronics/GCM188R71C104KA37D?qs=aEuGZpxfbxWKAxwYn%252BeTMg%3D%3D
"Manufacturer_Name" Murata Electronics
"Manufacturer_Part_Number" GCM188R71C104KA37D
"Description" Murata 100nF Multilayer Ceramic Capacitor MLCC 16V dc +/-10% X7R Dielectric 0603 (1608M) SMD, Max. Temp. +125C
"Datasheet Link" https://search.murata.co.jp/Ceramy/image/img/A01X/G101/ENG/GCM188R71C104KA37-01A.pdf
"Geometry.Height" 0.9mm
GATE 1 2 0
GCM188R71C104KA37D
1 0 U 1
2 0 U 2

*END*
*REMARK* SamacSys ECAD Model
771761/502518/2.50/2/2/Capacitor
