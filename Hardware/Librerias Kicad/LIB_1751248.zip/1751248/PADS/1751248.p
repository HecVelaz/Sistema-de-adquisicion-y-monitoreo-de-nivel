*PADS-LIBRARY-PART-TYPES-V9*

1751248 1751248 I CON 7 1 0 0 0
TIMESTAMP 2026.03.29.12.09.32
"Mouser Part Number" 651-1751248
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Phoenix-Contact/1751248?qs=bOnNDoERoR01kuhsqWf5xQ%3D%3D
"Manufacturer_Name" Phoenix Contact
"Manufacturer_Part_Number" 1751248
"Description" PCB terminal block, 3.5mm pitch, 2 way Phoenix Contact COMBICON MKDS Series 3.5mm Pitch Straight PCB Terminal Block with Screw Termination, Through Hole
"Datasheet Link" https://www.phoenixcontact.com/en-us/products/printed-circuit-board-terminal-mkds-1-2-35-1751248?type=pdf
"Geometry.Height" 8.65mm
GATE 1 2 0
1751248
1 0 U 1
2 0 U 2

*END*
*REMARK* SamacSys ECAD Model
321483/2017949/2.50/2/2/Connector
