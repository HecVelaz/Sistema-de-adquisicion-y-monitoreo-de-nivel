*PADS-LIBRARY-PART-TYPES-V9*

DS3231MZ+ SOIC127P600X175-8N I ANA 7 1 0 0 0
TIMESTAMP 2026.03.28.21.01.11
"Mouser Part Number" 700-DS3231MZ+
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Analog-Devices-Maxim-Integrated/DS3231MZ%2b?qs=4Rc5iGDDRGgASPOHxzykqQ%3D%3D
"Manufacturer_Name" Analog Devices
"Manufacturer_Part_Number" DS3231MZ+
"Description" Real Time Clock 5+/-ppm RTC
"Datasheet Link" http://datasheets.maximintegrated.com/en/ds/DS3231M.pdf
"Geometry.Height" 1.75mm
GATE 1 8 0
DS3231MZ+
1 0 U 32KHZ
2 0 U VCC
3 0 U \INT\/SQW
4 0 U \RST
8 0 U SCL
7 0 U SDA
6 0 U VBAT
5 0 U GND

*END*
*REMARK* SamacSys ECAD Model
231928/502518/2.50/8/3/Integrated Circuit
