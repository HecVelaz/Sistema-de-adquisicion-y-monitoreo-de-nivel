*PADS-LIBRARY-PART-TYPES-V9*

T495C226K025AHE300 T495C I CAP 7 1 0 0 0
TIMESTAMP 2026.03.29.10.19.49
"Mouser Part Number" 
"Mouser Price/Stock" 
"Manufacturer_Name" Yageo Group
"Manufacturer_Part_Number" T495C226K025AHE300
"Description" SMD, MnO2, Molded, Low ESR
"Datasheet Link" https://www.yageogroup.com/content/datasheet/asset/file/KEM_T2009_T495
"Geometry.Height" 2.8mm
GATE 1 2 0
T495C226K025AHE300
1 0 U +
2 0 U -

*END*
*REMARK* SamacSys ECAD Model
15917996/502518/2.50/2/2/Capacitor Polarised
