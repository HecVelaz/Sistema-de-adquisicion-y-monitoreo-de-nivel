*PADS-LIBRARY-PART-TYPES-V9*

RASM722PTR13X RASM722X I CON 6 1 0 0 0
TIMESTAMP 2026.03.28.19.45.36
"Mouser Part Number" 502-RASM722PTR13X
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Switchcraft/RASM722PTR13X?qs=NW1tGwZwExFzXYAsdXkb2Q%3D%3D
"Manufacturer_Name" Switchcraft
"Manufacturer_Part_Number" RASM722PTR13X
"Description" DC Power Connectors Connectors, Interconnects Barrel - Power - CONN JACK R/A .080" PIN SMD
"Datasheet Link" http://www.switchcraft.com/Drawings/rasm722px_cd.pdf
GATE 1 3 0
RASM722PTR13X
1 0 U TIP_TERMINAL_(CENTER_PIN)
2 0 U SHUNT_TERMINAL
3 0 U SLEEVE_TERMINAL

*END*
*REMARK* SamacSys ECAD Model
300143/502518/2.50/3/4/Connector
