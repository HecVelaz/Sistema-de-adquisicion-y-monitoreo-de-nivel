*PADS-LIBRARY-PART-TYPES-V9*

GRM21BR60J226ME39L GRM21BR60J226ME39L I CAP 7 1 0 0 0
TIMESTAMP 2026.03.29.10.09.41
"Mouser Part Number" 81-GRM21R60J226ME39L
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Murata-Electronics/GRM21BR60J226ME39L?qs=DJY02EClX9n4vY1%2FNV53Qw%3D%3D
"Manufacturer_Name" Murata Electronics
"Manufacturer_Part_Number" GRM21BR60J226ME39L
"Description" MLCC, 0805
"Datasheet Link" https://search.murata.co.jp/Ceramy/image/img/A01X/G101/ENG/GRM21BR60J226ME39-01A.pdf
"Geometry.Height" 1.45mm
GATE 1 2 0
GRM21BR60J226ME39L
1 0 U 1
2 0 U 2

*END*
*REMARK* SamacSys ECAD Model
235725/502518/2.50/2/2/Capacitor
