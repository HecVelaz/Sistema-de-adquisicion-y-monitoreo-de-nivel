*PADS-LIBRARY-PART-TYPES-V9*

GRT21BR61A106KE01L GRT21BR61A106KE01L I CAP 7 1 0 0 0
TIMESTAMP 2026.03.29.09.57.32
"Mouser Part Number" 81-GRT21BR61A106KE1L
"Mouser Price/Stock" https://www.mouser.com/Search/Refine.aspx?Keyword=81-GRT21BR61A106KE1L
"Manufacturer_Name" Murata Electronics
"Manufacturer_Part_Number" GRT21BR61A106KE01L
"Description" Chip Multilayer Ceramic Capacitor Capacitance  10uF +/-10% Distance between external terminals g  0.7mm min. External terminal size e  0.2 to 0.7mm Operating Temperature Range  -55 to 85 Rated Voltage  10Vdc Size code in inch(mm)  0805 (2012M) Capacitance change rate  +/-15.0% Temperature characteristics (complied standard)  X5R(EIA) Temperature range of temperature characteristics  -55 to 85
"Datasheet Link" https://componentsearchengine.com/Datasheets/1/GRT21BR61A106KE01L.pdf
"Geometry.Height" 1.35mm
GATE 1 2 0
GRT21BR61A106KE01L
1 0 U 1
2 0 U 2

*END*
*REMARK* SamacSys ECAD Model
1174920/502518/2.50/2/2/Capacitor
