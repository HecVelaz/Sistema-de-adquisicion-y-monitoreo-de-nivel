*PADS-LIBRARY-PART-TYPES-V9*

SMTU2032-C.TR SMTU2032CTR I ANA 7 1 0 0 0
TIMESTAMP 2026.04.15.16.25.28
"Mouser Part Number" 614-SMTU2032-C.TR
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Renata/SMTU2032-C.TR?qs=UxeAxwACbqlbJ4Hul%252BCKVg%3D%3D
"Manufacturer_Name" RENATA
"Manufacturer_Part_Number" SMTU2032-C.TR
"Description" Coin Cell Battery Holders SMT HOLDER ON T&R FOR CR2032-485/REEL
"Datasheet Link" https://www.mouser.se/datasheet/2/346/SMTU2032-C-258020.pdf
"Geometry.Height" 5.6mm
GATE 1 3 0
SMTU2032-C.TR
1 0 U +
2 0 U EP
3 0 U -

*END*
*REMARK* SamacSys ECAD Model
544221/502518/2.50/3/3/Battery
