*PADS-LIBRARY-PART-TYPES-V9*

SP3485EN-L_TR SOIC127P600X175-8N I ANA 7 1 0 0 0
TIMESTAMP 2026.03.28.23.41.42
"Mouser Part Number" 701-SP3485EN-L/TR
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/MaxLinear/SP3485EN-L-TR?qs=3EMgrMjM0fbQ17liGrle%2Fg%3D%3D
"Manufacturer_Name" MaxLinear, Inc.
"Manufacturer_Part_Number" SP3485EN-L/TR
"Description" RS-485 Interface IC 3.3V LoPwr Half-Dup RS485w/10Mbps Data
"Datasheet Link" https://www.maxlinear.com/ds/sp3485.pdf
"Geometry.Height" 1.75mm
GATE 1 8 0
SP3485EN-L_TR
1 0 U RO
2 0 U \RE
3 0 U DE
4 0 U DI
8 0 U VCC
7 0 U B
6 0 U A
5 0 U GND

*END*
*REMARK* SamacSys ECAD Model
1676677/502518/2.50/8/4/Integrated Circuit
